import threading
def main():
	print threading.active_count()
if __name__=="__main__":
	main()